import os
import sys
sys.path.append('../')
import unittest
from app import app
from flask import request
from flask import Response

class auditsTests(unittest.TestCase):
        
  def test_read_audits(self):
      app.testing = True
      test = app.test_client()
      params = "query=user8&from=1&to=12345678900000000"
      response = test.get('/api/audits/', query_string=params, content_type='application/json')
      self.assertEqual(response.status_code, 200)
          
if __name__ == '__main__':
    unittest.main()
