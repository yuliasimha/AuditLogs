import sys
sys.path.append('../')
import unittest
import json
import jsonschema 
from utils.validator import validator as validator


class TestValidator(unittest.TestCase):

  
    schema = { 
        "type" : "object",
        "properties" : {   
        "time":  {"type" : "number"},
        "username": {"type" : "string"},
        "message":  {"type" : "string"},
        "action":  {"type" : "string"}
        },
        "required": ["time", "username", "message"]
    }

    def test_valid_json(self):
        json_data = '{"time": 712, "username": "user8", "message": "user8 connection succeeded","action": "connection"}'
        validator.validateInput(json_data, self.schema)

    def test_invalid_json_format(self):
        json_data =  '{"time": 712 "username": "user8", "message": "user8 connection succeeded","action": "connection"}'
        self.assertRaises(json.decoder.JSONDecodeError, validator.validateInput(json_data, self.schema))

    def test_invalid_json_schema_missing_type(self):
        json_data = '{"time": 712, "message": "user8 connection succeeded","action": "connection"}'
        self.assertRaises(jsonschema.exceptions.ValidationError, validator.validateInput(json_data, self.schema))

    def test_invalid_json_schema_missing_time(self):
        json_data = '{"username": "user8", "message": "user8 connection succeeded","action": "connection"}'
        self.assertRaises(jsonschema.exceptions.ValidationError, validator.validateInput(json_data, self.schema))

    def test_invalid_json_schema_missing_message(self):
        json_data = '{"time": 712, "username": "user8","action": "connection"}'
        self.assertRaises(jsonschema.exceptions.ValidationError, validator.validateInput(json_data, self.schema))

if __name__ == '__main__':
    unittest.main()
